## Installation
Install NodeJS https://nodejs.org/en/download/

## Usage
1. Install dependencies, run "npm install" in cmd
2. Install live-server, run "npm i -g live-server"
3. Start server, run "npm run server"
4. Start database & API, run "npm run db" (infor: https://www.npmjs.com/package/json-server)

## License
[MIT](https://choosealicense.com/licenses/mit/)